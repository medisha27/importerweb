import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Navbar() {
  const navigate = useNavigate();
  const isLogged = !!localStorage.getItem('token');

  function handleLogout() {
    localStorage.removeItem('token');
    navigate('/');
  }

  return (
    <nav>
      <Link to="/">Home</Link> | 
      <Link to="/about">About Us</Link> | 
      <Link to="/services">Services</Link> | 
      <Link to="/contact">Contact</Link> | 
      <Link to="/quote">Get a Quote</Link> | 
      {isLogged ? (
        <>
          <Link to="/dashboard">Dashboard</Link>
          <button onClick={handleLogout}>Logout</button>
        </>
      ) : (
        <>
          <Link to="/login">Login</Link>
          <Link to="/signup">Sign Up</Link>
        </>
      )}
    </nav>
  );
}

export default Navbar;