import React, { useState } from 'react';
import axios from 'axios';

function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [msg, setMsg] = useState('');

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const res = await axios.post('http://localhost:5000/api/contact', form);
    setMsg(res.data.message);
  }

  return (
    <div>
      <h1>Contact Us</h1>
      <form onSubmit={handleSubmit}>
        <input name="name" placeholder="Name" onChange={handleChange} required /><br/>
        <input name="email" placeholder="Email" onChange={handleChange} required /><br/>
        <textarea name="message" placeholder="Your Message" onChange={handleChange} required /><br/>
        <button type="submit">Send Message</button>
      </form>
      <div>{msg}</div>
    </div>
  );
}

export default Contact;