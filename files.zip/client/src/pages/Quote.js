import React, { useState } from 'react';
import axios from 'axios';

function Quote() {
  const [form, setForm] = useState({ name: '', email: '', details: '' });
  const [msg, setMsg] = useState('');

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const res = await axios.post('http://localhost:5000/api/quote', form);
    setMsg(res.data.message);
  }

  return (
    <div>
      <h1>Request a Quote</h1>
      <form onSubmit={handleSubmit}>
        <input name="name" placeholder="Name" onChange={handleChange} required /><br/>
        <input name="email" placeholder="Email" onChange={handleChange} required /><br/>
        <textarea name="details" placeholder="Describe your requirements" onChange={handleChange} required /><br/>
        <button type="submit">Request Quote</button>
      </form>
      <div>{msg}</div>
    </div>
  );
}

export default Quote;