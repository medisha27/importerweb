import React from 'react';

function About() {
  return (
    <div>
      <h1>About Us</h1>
      <p>We specialize in global import/export solutions with decades of experience.</p>
    </div>
  );
}

export default About;