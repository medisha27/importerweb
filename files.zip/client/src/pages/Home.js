import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div>
      <h1>Welcome to ImporterWeb</h1>
      <p>Your trusted import/export partner.</p>
      <Link to="/quote"><button>Get a Quote</button></Link>
      <Link to="/contact"><button>Contact Us</button></Link>
    </div>
  );
}

export default Home;