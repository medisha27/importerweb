import React from 'react';

function Services() {
  return (
    <div>
      <h1>Our Services</h1>
      <ul>
        <li>Customs Clearance</li>
        <li>Shipping and Logistics</li>
        <li>Supply Chain Management</li>
        <li>Documentation Assistance</li>
      </ul>
      <button>Learn More</button>
    </div>
  );
}

export default Services;