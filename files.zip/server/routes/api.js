const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

function authMiddleware(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ message: 'No token' });
  try {
    const token = header.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ message: 'Invalid token' });
  }
}

// Contact form endpoint
router.post('/contact', (req, res) => {
  // Save or email contact data here
  res.json({ message: 'Contact form submitted!' });
});

// Quote request endpoint
router.post('/quote', (req, res) => {
  // Save or email quote data here
  res.json({ message: 'Quote request submitted!' });
});

// Dashboard (protected)
router.get('/dashboard', authMiddleware, (req, res) => {
  res.json({ message: `Welcome, ${req.user.email}! Here is your dashboard data.` });
});

module.exports = router;